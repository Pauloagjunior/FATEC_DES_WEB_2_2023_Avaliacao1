<?php
session_start();
?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>pagina2</title>
</head>

<body>
    <?php
    echo '<h2>Seja bem vindo ' . $_SESSION['login'] . '!</h2>';
    ?>
    <h2>Cadastrar registro</h2>
    <form method="post" action="cadastrar.php">
        <label for="prateleira">Prateleira:</label>
        <input type="text" name="prateleira" id="prateleira">
        <br><br>
        <label for="livro">Nome do livro(a):</label>
        <input type="text" name="livro" id="livro">
        <br><br>
        <label for="data">Data de lançamento:</label>
        <input type="text" name="data" id="data">
        <br><br>
        <input type="submit" name="cadastrar" value="Registrar">
    </form>

    <br>
    <a href="pag4.php">Visualizar registros</a>
    <br>
    <a href="pag3.php">Encerrar sessão</a>
</body>

</html>
